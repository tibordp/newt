Edge captures, 2026-10-08. Handshakes to the TLS front end.
